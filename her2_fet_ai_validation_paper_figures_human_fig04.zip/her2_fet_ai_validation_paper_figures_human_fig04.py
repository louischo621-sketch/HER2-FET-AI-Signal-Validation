"""
HER2 FET-Based Biosensor AI-Assisted Signal Validation
=========================================================

用途
----
把本程式放在含有 HER2 FET-based biosensor 實驗 CSV 的資料夾中執行。
程式會自動：

1. 讀取資料夾內所有 CSV 檔案
2. 依照 PBS → HER2 濃度序列切出穩態響應
3. 使用較通用的 physics-informed 規則產生 conservative teacher pseudo-label
4. 擷取三通道時域波形：raw-normalized、z-score、derivative
5. 擷取物理特徵：final drop、slope、R²、PBS noise、SNR、monotonicity 等
6. 使用 physics-guided 1D-CNN 做 signal validation
7. 使用 Leave-One-Experiment-Out，也就是以 CSV 檔案為 group 做交叉驗證
8. 輸出混淆矩陣、分類指標、線性/對數檢量線比較圖、disagreement 波形圖與 CSV 報告

核心研究定位
------------
這支程式不是直接用 AI 回推 HER2 濃度，而是讓 AI 做：
「HER2 FET-based biosensor 多通道訊號品質評估」。

AI 通過篩選後，再用可信 channel 建立比較穩定的 HER2 calibration curve。

資料欄位需求
------------
CSV 需要至少包含：
- Channel
- Interval
- DeltaId

若欄位名稱略有不同，程式會嘗試自動辨識。

建議執行方式
------------
python her2_fet_ai_validation_recommended.py

輸出資料夾
----------
./her2_ai_results/
"""

import os
import re
import glob
import json
import math
import random
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    accuracy_score,
    r2_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    matthews_corrcoef,
    cohen_kappa_score,
    roc_auc_score,
    average_precision_score,
)
from sklearn.model_selection import LeaveOneGroupOut, LeaveOneOut
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

warnings.filterwarnings("ignore")

# ============================================================
# 0. 全域設定：你最常需要改的地方集中在這裡
# ============================================================

SEED = 42
np.random.seed(SEED)
random.seed(SEED)

# 輸入與輸出
CSV_GLOB = "*.csv"
EXCLUDE_PREFIXES = ("MASTER_", "summary_", "predictions_", "metrics_")
RESULT_DIR = Path("./her2_ai_results")
RESULT_DIR.mkdir(exist_ok=True)
(RESULT_DIR / "mismatch_waveforms").mkdir(exist_ok=True)
(RESULT_DIR / "all_waveforms").mkdir(exist_ok=True)
(RESULT_DIR / "paper_figures").mkdir(exist_ok=True)


def safe_to_csv(df, path, **kwargs):
    """
    Windows / Excel 常會鎖住已開啟的 CSV。
    若原檔無法覆寫，會自動另存成加上時間戳記的新檔名，避免程式中斷。
    """
    path = Path(path)
    try:
        df.to_csv(path, **kwargs)
        return path
    except PermissionError:
        stamp = pd.Timestamp.now().strftime("%Y%m%d_%H%M%S")
        alt = path.with_name(f"{path.stem}_{stamp}{path.suffix}")
        print(f"  [警告] 無法寫入 {path}，可能檔案正在被 Excel 或其他程式開啟。")
        print(f"  [改存] {alt}")
        df.to_csv(alt, **kwargs)
        return alt

# HER2 濃度時程設定
# ------------------------------------------------------------
# 新版重點：
# 1. CH9 可被排除，避免把機台 reference / 平穩訊號當成 sensing channel。
# 2. 每個 CSV 會依照自己的最大時間自動切 phase。
#    例如：
#    - 總時間約 2400 s → 每段 400 s
#    - 總時間約 3600 s → 每段 600 s
# 前提：每個 CSV 的濃度順序相同，且每個 phase 時間長度相同。
# ------------------------------------------------------------

EXCLUDE_CHANNELS = {9}       # CH9 是機台 reference / 平穩訊號，不納入 HER2 sensing 分析
AUTO_PHASE_BY_FILE = True    # True：每個 CSV 依 max Interval 自動切濃度區間
DEFAULT_PHASE_DURATION_SECONDS = 400
COMMON_PHASE_DURATIONS = [400, 600]  # 常見 phase 長度；用來修正 2390→400、3590→600 等情況

PHASE_SEQUENCE = [
    ("PBS", 0.0),
    ("1 ng/mL", 1.0),
    ("5 ng/mL", 5.0),
    ("10 ng/mL", 10.0),
    ("15 ng/mL", 15.0),
    ("25 ng/mL", 25.0),
]

def build_phases(phase_duration_seconds):
    """根據每段濃度時間自動建立 PHASES。"""
    phases = []
    for i, (name, conc) in enumerate(PHASE_SEQUENCE):
        phases.append({
            "name": name,
            "end": float(phase_duration_seconds) * (i + 1),
            "conc": float(conc),
        })
    return phases

def infer_phase_duration_seconds(df):
    """
    根據每個 CSV 的最大 Interval 自動判斷每段濃度時間。
    例如：
    max Interval ≈ 2390/2400 → phase duration = 400
    max Interval ≈ 3590/3600 → phase duration = 600
    """
    max_t = float(df["Interval"].max())
    n_phase = len(PHASE_SEQUENCE)

    # 儀器資料常會停在 2390 或 3590 秒，因此用 (max_t + 取樣間隔) 估計總時間。
    intervals = np.sort(df["Interval"].dropna().unique())
    if len(intervals) >= 2:
        dt = float(np.median(np.diff(intervals)))
        if not np.isfinite(dt) or dt <= 0:
            dt = 0.0
    else:
        dt = 0.0

    estimated_total = max_t + dt
    raw_duration = estimated_total / n_phase

    # 先四捨五入到最接近的 10 秒
    duration = int(round(raw_duration / 10.0) * 10)

    # 如果接近常用設定，就校正成 400 或 600
    nearest = min(COMMON_PHASE_DURATIONS, key=lambda x: abs(x - duration))
    if abs(nearest - duration) <= 40:
        duration = int(nearest)

    return max(1, int(duration))

def get_phases_for_file(df):
    """回傳該 CSV 專屬的 phases 與 phase_duration。"""
    if AUTO_PHASE_BY_FILE:
        phase_duration = infer_phase_duration_seconds(df)
    else:
        phase_duration = DEFAULT_PHASE_DURATION_SECONDS
    phases = build_phases(phase_duration)
    return phases, phase_duration

# 保留一個預設 PHASES，給舊函式 fallback 與設定輸出使用。
PHASES = build_phases(DEFAULT_PHASE_DURATION_SECONDS)

# 每一段濃度最後多少秒視為穩態區間
STEADY_WINDOW_SECONDS = 100

# 是否跳過一開始不穩定的秒數。
# 若你想完整保留 PBS，維持 0。
# 若開機或滴液瞬間有大突波，可改成 30、50、100。
SKIP_SECONDS = 0

# 波形重取樣長度
TARGET_LEN = 240

# Rule-based teacher 門檻
# ------------------------------------------------------------
# 這裡的規則定位是 conservative physics-informed pseudo-label，
# 不是絕對 ground truth。設計目標是：老師問起來時，每個條件都有物理意義。
# ------------------------------------------------------------
MIN_PHASE_POINTS = 4

# 最小絕對響應量。單位依你的 DeltaId 而定。
# 這是避免把幾乎沒有反應的 channel 當成 valid。
SIGNAL_THRESHOLD = 0.05

# 若 PBS noise 可估計，valid response 必須同時大於 SNR_THRESHOLD_FOR_LABEL × PBS_std。
# 這比單純使用固定門檻更通用，因為不同實驗 noise 不一定一樣。
USE_NOISE_ADAPTIVE_SIGNAL_GATE = True
SNR_THRESHOLD_FOR_LABEL = 3.0
SNR_THRESHOLD_FOR_INFO = 3.0

# 單調性容忍度。Drop 若下降超過 MONO_TOL 才算 reverse step。
# 生物感測器允許少量波動，因此不建議一個 reverse step 就直接全部淘汰。
MONO_TOL = 0.05
MONOTONICITY_SCORE_THRESHOLD = 0.75
MAX_REVERSE_STEPS_FOR_VALID = 1

# Calibration consistency。
# 使用 linear R² 與 log-concentration R² 中較好的那個作為 teacher gate，
# 因為生物感測器常見 log-dose response。
R2_THRESHOLD = 0.75
CALIBRATION_R2_MODE = "best_of_linear_or_log"

# AI 與 teacher 不一致時的候選等級門檻。
BORDERLINE_AI_HIGH_PROB = 0.80
BORDERLINE_AI_LOW_PROB = 0.20

# CNN 訓練設定
EPOCHS = 60
BATCH_SIZE = 8
LEARNING_RATE = 1e-3
AI_THRESHOLD = 0.5
N_AUG_POS = 4                 # 正樣本資料增強倍數
NOISE_STD = 0.04
SHIFT_MAX = 10
USE_DILATED_CNN = True

# 若資料很小，Keras 每 fold 會訓練很多次，時間會比較久。
# 沒有 TensorFlow 時會自動使用 SVM fallback。
try:
    import tensorflow as tf
    from tensorflow import keras
    from tensorflow.keras import layers

    tf.random.set_seed(SEED)
    USE_KERAS = True
    print("TensorFlow 載入成功：使用 physics-guided 1D-CNN。")
except ImportError:
    USE_KERAS = False
    print("未偵測到 TensorFlow：改用 SVM fallback。")


# ============================================================
# 1. CSV 讀取與欄位辨識
# ============================================================

def _norm_colname(s):
    """把欄位名稱轉成容易比對的格式。"""
    s = str(s).strip().lower()
    s = s.replace("δ", "delta").replace("∆", "delta").replace("Δ", "delta")
    s = re.sub(r"[\s_\-\(\)\[\]/\\]+", "", s)
    return s


def _find_column(columns, role):
    """嘗試從不同儀器欄名中找到 Channel / Interval / DeltaId。"""
    norm_map = {_norm_colname(c): c for c in columns}
    norms = list(norm_map.keys())

    if role == "channel":
        candidates = ["channel", "ch", "chan"]
        for cand in candidates:
            if cand in norm_map:
                return norm_map[cand]
        for n in norms:
            if "channel" in n:
                return norm_map[n]

    if role == "interval":
        candidates = ["interval", "time", "times", "second", "seconds", "sec"]
        for cand in candidates:
            if cand in norm_map:
                return norm_map[cand]
        for n in norms:
            if "interval" in n or "time" in n:
                return norm_map[n]

    if role == "deltaid":
        candidates = [
            "deltaid", "deltaids", "deltai", "deltai", "deltacurrent",
            "did", "deltaidsma", "deltaidmA".lower(), "idchange", "currentchange"
        ]
        for cand in candidates:
            cand_norm = _norm_colname(cand)
            if cand_norm in norm_map:
                return norm_map[cand_norm]
        for n in norms:
            if "delta" in n and ("id" in n or "current" in n or "i" in n):
                return norm_map[n]
            if n in ("id", "ids", "draincurrent"):
                # 若你的檔案只有 Id，這裡會把它當 DeltaId。
                # 但建議你還是輸出 DeltaId 比較清楚。
                return norm_map[n]

    return None


def read_csv_smart(path):
    """
    自動尋找包含 Channel 與 Interval 的表頭，跳過儀器參數列。
    成功時回傳標準化欄位：Channel, Interval, DeltaId。
    """
    encodings = ["utf-8", "utf-8-sig", "utf-16-le", "big5", "cp950", "cp1252"]

    for enc in encodings:
        try:
            header_idx = 0
            with open(path, "r", encoding=enc, errors="ignore") as f:
                for i, line in enumerate(f):
                    low = line.lower()
                    if ("channel" in low or "ch" in low) and ("interval" in low or "time" in low):
                        header_idx = i
                        break

            df = pd.read_csv(path, skiprows=header_idx, encoding=enc, encoding_errors="ignore")
            df.columns = [str(c).strip() for c in df.columns]

            ch_col = _find_column(df.columns, "channel")
            t_col = _find_column(df.columns, "interval")
            d_col = _find_column(df.columns, "deltaid")

            if ch_col is None or t_col is None or d_col is None:
                continue

            out = df[[ch_col, t_col, d_col]].copy()
            out.columns = ["Channel", "Interval", "DeltaId"]

            out["Channel"] = pd.to_numeric(out["Channel"], errors="coerce")
            out["Interval"] = pd.to_numeric(out["Interval"], errors="coerce")
            out["DeltaId"] = pd.to_numeric(out["DeltaId"], errors="coerce")
            out = out.dropna(subset=["Channel", "Interval", "DeltaId"])

            if len(out) == 0:
                continue

            return out
        except Exception:
            continue

    return None


# ============================================================
# 2. 物理規則與特徵擷取
# ============================================================

def extract_steady(ch_data, phases=None):
    """
    依照該 CSV 的 phases 設定，擷取每個濃度階段最後 STEADY_WINDOW_SECONDS 的平均 DeltaId。
    回傳每個濃度的 Drop = PBS baseline - current mean。
    """
    if phases is None:
        phases = PHASES

    pts = []
    baseline = None
    pbs_std = np.nan

    for ph in phases:
        start = ph["end"] - STEADY_WINDOW_SECONDS
        end = ph["end"]
        seg = ch_data[(ch_data["Interval"] >= start) & (ch_data["Interval"] <= end)]

        if seg.empty:
            continue

        mu = float(seg["DeltaId"].mean())
        sd = float(seg["DeltaId"].std(ddof=1)) if len(seg) > 1 else 0.0

        if ph["conc"] == 0 or str(ph["name"]).upper() == "PBS":
            baseline = mu
            pbs_std = sd
            pts.append({
                "Phase": ph["name"],
                "Conc": float(ph["conc"]),
                "MeanDeltaId": mu,
                "Phase_std": sd,
                "Drop": 0.0,
                "PBS_std": pbs_std,
                "N": int(len(seg)),
                "Window_start": float(start),
                "Window_end": float(end),
            })
        else:
            if baseline is None:
                # 沒有 PBS baseline 就不計算後面的 drop
                continue
            pts.append({
                "Phase": ph["name"],
                "Conc": float(ph["conc"]),
                "MeanDeltaId": mu,
                "Phase_std": sd,
                "Drop": float(baseline - mu),
                "PBS_std": pbs_std,
                "N": int(len(seg)),
                "Window_start": float(start),
                "Window_end": float(end),
            })

    return pd.DataFrame(pts)


def _safe_linear_fit(x, y):
    """安全線性擬合，回傳 slope, intercept, r2。會自動排除 NaN / inf。"""
    x = np.asarray(x, dtype=float).reshape(-1)
    y = np.asarray(y, dtype=float).reshape(-1)

    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]

    if len(y) < 2 or len(np.unique(x)) < 2:
        return np.nan, np.nan, np.nan

    X = x.reshape(-1, 1)
    model = LinearRegression().fit(X, y)
    pred = model.predict(X)

    try:
        r2 = r2_score(y, pred, force_finite=True)
    except TypeError:
        r2 = r2_score(y, pred)
    except Exception:
        r2 = np.nan

    return float(model.coef_[0]), float(model.intercept_), float(r2)


def _safe_log_concentration_fit(conc, response):
    """
    對非零濃度做 log10(concentration) fitting。
    PBS = 0 不能取 log，因此會自動排除。

    回傳：log_slope, log_intercept, log_r2
    這裡的 log_slope 單位可理解為：每增加 1 decade 濃度時，Drop 改變多少。
    """
    conc = np.asarray(conc, dtype=float).reshape(-1)
    response = np.asarray(response, dtype=float).reshape(-1)

    mask = (conc > 0) & np.isfinite(conc) & np.isfinite(response)
    conc_nz = conc[mask]
    resp_nz = response[mask]

    if len(resp_nz) < 2 or len(np.unique(conc_nz)) < 2:
        return np.nan, np.nan, np.nan

    x_log = np.log10(conc_nz)
    return _safe_linear_fit(x_log, resp_nz)


def compute_pbs_drift(ch_data, phases=None):
    """估算完整 PBS 區間的 drift rate 與 total drift。"""
    if phases is None:
        phases = PHASES
    pbs_end = phases[0]["end"]
    pbs = ch_data[(ch_data["Interval"] >= 0) & (ch_data["Interval"] <= pbs_end)]
    if len(pbs) < 5:
        return np.nan, np.nan
    x = pbs[["Interval"]].values
    y = pbs["DeltaId"].values
    model = LinearRegression().fit(x, y)
    drift_rate = float(model.coef_[0])
    total_drift = float(drift_rate * (pbs["Interval"].max() - pbs["Interval"].min()))
    return drift_rate, total_drift


def extract_physics_features(ch_data, calib_df, phases=None):
    """
    將每個 channel 轉成物理特徵。
    這些特徵會餵給 physics feature branch，也會輸出成表格方便你寫論文。
    """
    default = {
        "final_drop": np.nan,
        "slope": np.nan,
        "intercept": np.nan,
        "r2": np.nan,
        "log_slope": np.nan,
        "log_intercept": np.nan,
        "log_r2": np.nan,
        "pbs_std": np.nan,
        "pbs_drift_rate": np.nan,
        "pbs_total_drift": np.nan,
        "snr": np.nan,
        "monotonicity_score": np.nan,
        "num_reverse_steps": np.nan,
        "mean_phase_std": np.nan,
        "steady_cv_mean": np.nan,
        "response_range": np.nan,
        "quality_score": np.nan,
    }

    if calib_df is None or calib_df.empty:
        return default

    conc = calib_df["Conc"].values.astype(float)
    drops = calib_df["Drop"].values.astype(float)

    final_drop = float(drops[-1]) if len(drops) > 0 else np.nan
    slope, intercept, r2 = _safe_linear_fit(conc, drops)
    log_slope, log_intercept, log_r2 = _safe_log_concentration_fit(conc, drops)

    pbs_std = float(calib_df["PBS_std"].iloc[0]) if "PBS_std" in calib_df else np.nan
    pbs_drift_rate, pbs_total_drift = compute_pbs_drift(ch_data, phases=phases)

    if np.isfinite(pbs_std) and pbs_std > 1e-12 and np.isfinite(final_drop):
        snr = float(abs(final_drop) / pbs_std)
    else:
        snr = np.nan

    if len(drops) >= 2:
        diff = np.diff(drops)
        ok_steps = diff >= -MONO_TOL
        monotonicity_score = float(np.mean(ok_steps))
        num_reverse_steps = int(np.sum(~ok_steps))
    else:
        monotonicity_score = np.nan
        num_reverse_steps = np.nan

    mean_phase_std = float(calib_df["Phase_std"].mean()) if "Phase_std" in calib_df else np.nan

    nonzero = calib_df[calib_df["Conc"] > 0]
    cvs = []
    for _, row in nonzero.iterrows():
        denom = abs(float(row["Drop"]))
        if denom > 1e-12:
            cvs.append(abs(float(row["Phase_std"])) / denom)
    steady_cv_mean = float(np.mean(cvs)) if len(cvs) else np.nan

    response_range = float(ch_data["DeltaId"].max() - ch_data["DeltaId"].min()) if len(ch_data) else np.nan

    # Soft quality score：不是硬標籤，只是輔助你觀察 channel 品質。
    # 這裡同時考慮 linear R² 與 log R²，較符合 biosensor 常見的 log-dose response。
    r2_candidates = [v for v in [r2, log_r2] if np.isfinite(v)]
    best_r2_for_score = max(r2_candidates) if len(r2_candidates) else np.nan
    r2_score_clip = 0.0 if not np.isfinite(best_r2_for_score) else np.clip((best_r2_for_score - 0.5) / 0.5, 0, 1)

    signal_score = 0.0 if not np.isfinite(final_drop) else np.clip(final_drop / max(3 * SIGNAL_THRESHOLD, 1e-9), 0, 1)
    snr_score = 0.0 if not np.isfinite(snr) else np.clip(snr / 5.0, 0, 1)
    mono_score = 0.0 if not np.isfinite(monotonicity_score) else np.clip(monotonicity_score, 0, 1)
    if np.isfinite(pbs_std):
        pbs_stability_score = np.clip(1.0 - pbs_std / max(SIGNAL_THRESHOLD, 1e-9), 0, 1)
    else:
        pbs_stability_score = 0.0

    quality_score = float(
        0.30 * r2_score_clip
        + 0.25 * mono_score
        + 0.20 * signal_score
        + 0.15 * snr_score
        + 0.10 * pbs_stability_score
    )

    out = default.copy()
    out.update({
        "final_drop": final_drop,
        "slope": slope,
        "intercept": intercept,
        "r2": r2,
        "log_slope": log_slope,
        "log_intercept": log_intercept,
        "log_r2": log_r2,
        "pbs_std": pbs_std,
        "pbs_drift_rate": pbs_drift_rate,
        "pbs_total_drift": pbs_total_drift,
        "snr": snr,
        "monotonicity_score": monotonicity_score,
        "num_reverse_steps": num_reverse_steps,
        "mean_phase_std": mean_phase_std,
        "steady_cv_mean": steady_cv_mean,
        "response_range": response_range,
        "quality_score": quality_score,
    })
    return out


def _best_calibration_r2(feature_dict):
    """回傳 linear R² 與 log R² 中較好的值與來源。"""
    r2 = feature_dict.get("r2", np.nan)
    log_r2 = feature_dict.get("log_r2", np.nan)

    candidates = []
    if np.isfinite(r2):
        candidates.append((float(r2), "linear_r2"))
    if np.isfinite(log_r2):
        candidates.append((float(log_r2), "log_r2"))

    if len(candidates) == 0:
        return np.nan, "none"

    return max(candidates, key=lambda x: x[0])


def rule_based_label(calib_df, feature_dict):
    """
    Conservative physics-informed Teacher。

    回傳：label_bool, reason。

    這裡的 label 是 pseudo-label，不是絕對 ground truth。
    設計邏輯：
    1. 訊號必須大於固定門檻，也最好大於 PBS noise 的數倍。
    2. 反應方向必須符合預期，也就是 Drop 隨濃度增加大致增加。
    3. 允許少量 non-monotonic fluctuation，但不接受多次反向。
    4. 檢量線可用 linear R² 或 log-concentration R² 通過，較符合 biosensor 現實。
    """
    if calib_df is None or calib_df.empty or len(calib_df) < MIN_PHASE_POINTS:
        return False, "insufficient_data"

    final_drop = feature_dict.get("final_drop", np.nan)
    slope = feature_dict.get("slope", np.nan)
    log_slope = feature_dict.get("log_slope", np.nan)
    pbs_std = feature_dict.get("pbs_std", np.nan)
    snr = feature_dict.get("snr", np.nan)
    mono_score = feature_dict.get("monotonicity_score", np.nan)
    num_reverse = feature_dict.get("num_reverse_steps", np.nan)
    best_r2, best_r2_source = _best_calibration_r2(feature_dict)

    # Gate 1: response magnitude + noise-adaptive SNR gate
    if not np.isfinite(final_drop) or final_drop <= 0:
        return False, "low_signal"

    adaptive_signal_threshold = SIGNAL_THRESHOLD
    if USE_NOISE_ADAPTIVE_SIGNAL_GATE and np.isfinite(pbs_std) and pbs_std > 0:
        adaptive_signal_threshold = max(SIGNAL_THRESHOLD, SNR_THRESHOLD_FOR_LABEL * pbs_std)

    if final_drop < adaptive_signal_threshold:
        if np.isfinite(snr):
            return False, f"low_signal_or_low_snr_{snr:.2f}"
        return False, "low_signal_or_low_snr"

    # Gate 2: response direction
    # linear slope 或 log slope 至少一個要為正，避免把反向響應當成 HER2-dependent drop。
    positive_direction = False
    if np.isfinite(slope) and slope > 0:
        positive_direction = True
    if np.isfinite(log_slope) and log_slope > 0:
        positive_direction = True
    if not positive_direction:
        return False, "wrong_direction"

    # Gate 3: soft monotonicity
    # 允許一個濃度點有小幅異常，但不接受整體反覆上上下下。
    if not np.isfinite(mono_score):
        return False, "monotonicity_nan"
    if mono_score < MONOTONICITY_SCORE_THRESHOLD:
        return False, f"non_monotonic_score_{mono_score:.2f}"
    if np.isfinite(num_reverse) and int(num_reverse) > MAX_REVERSE_STEPS_FOR_VALID:
        return False, f"multiple_reverse_steps_{int(num_reverse)}"

    # Gate 4: calibration consistency
    # 使用 linear / log 中較好的 R²。若 log R² 通過，代表訊號可能符合 log-dose response。
    if not np.isfinite(best_r2) or best_r2 < R2_THRESHOLD:
        r2_text = "nan" if not np.isfinite(best_r2) else f"{best_r2:.2f}"
        return False, f"low_best_r2_{r2_text}"

    return True, f"pass_{best_r2_source}_{best_r2:.2f}"


FEATURE_COLUMNS = [
    "final_drop",
    "slope",
    "r2",
    "log_slope",
    "log_r2",
    "pbs_std",
    "pbs_total_drift",
    "snr",
    "monotonicity_score",
    "num_reverse_steps",
    "mean_phase_std",
    "steady_cv_mean",
    "response_range",
    "quality_score",
]


# ============================================================
# 3. 三通道波形擷取
# ============================================================

def extract_waveform_multichannel(ch_data, target_len=TARGET_LEN, phases=None):
    """
    回傳 shape = (target_len, 3)

    三個 channel 分別是：
    1. baseline-relative raw normalized waveform
    2. z-score waveform
    3. derivative of z-score waveform
    """
    if phases is None:
        phases = PHASES

    if SKIP_SECONDS > 0:
        used = ch_data[ch_data["Interval"] > SKIP_SECONDS].copy()
    else:
        used = ch_data.copy()

    used = used.sort_values("Interval")
    ts = used["DeltaId"].values.astype(np.float32)

    if len(ts) < 10:
        return None

    x_orig = np.linspace(0, 1, len(ts))
    x_new = np.linspace(0, 1, target_len)
    y = np.interp(x_new, x_orig, ts).astype(np.float32)

    # 估計 PBS 在重取樣波形中所佔比例，作為 baseline 區間。
    total_end = phases[-1]["end"]
    pbs_end = phases[0]["end"]
    pbs_n = max(5, int(target_len * pbs_end / total_end))
    baseline = float(np.mean(y[:pbs_n]))
    y_rel = y - baseline

    # channel 1: 保留趨勢與相對振幅，但避免不同檔案數值尺度差太大。
    robust_scale = np.percentile(np.abs(y_rel), 95)
    if robust_scale < 1e-9:
        robust_scale = np.max(np.abs(y_rel))
    if robust_scale < 1e-9:
        return None
    raw_norm = y_rel / robust_scale

    # channel 2: z-score，強調波形形狀。
    mu, sd = float(np.mean(y)), float(np.std(y))
    if sd < 1e-9:
        return None
    z = (y - mu) / sd

    # channel 3: derivative，強調注入暫態、漂移、反應速度。
    dz = np.gradient(z).astype(np.float32)

    out = np.stack([raw_norm, z, dz], axis=-1).astype(np.float32)
    out = np.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)
    return out


# ============================================================
# 4. 資料增強與模型
# ============================================================

def augment_waveforms(X_wave_pos, n_aug=N_AUG_POS, noise_std=NOISE_STD, shift_max=SHIFT_MAX):
    """
    只對 training set 內的正樣本做 augmentation，避免資料洩漏。
    """
    if len(X_wave_pos) == 0 or n_aug <= 0:
        return np.empty((0,) + X_wave_pos.shape[1:], dtype=np.float32)

    augmented = []
    for x in X_wave_pos:
        for _ in range(n_aug):
            aug = x.copy()

            # 小幅白噪音
            aug[:, 0] += np.random.normal(0, noise_std, size=aug[:, 0].shape)
            aug[:, 1] += np.random.normal(0, noise_std, size=aug[:, 1].shape)

            # 小幅時間平移
            shift = np.random.randint(-shift_max, shift_max + 1)
            aug = np.roll(aug, shift, axis=0)

            # 重新計算 derivative channel
            aug[:, 2] = np.gradient(aug[:, 1])

            augmented.append(aug.astype(np.float32))

    return np.asarray(augmented, dtype=np.float32)


def build_physics_guided_cnn(input_len=TARGET_LEN, n_wave_ch=3, n_feat=len(FEATURE_COLUMNS)):
    """
    Physics-guided 1D-CNN：
    waveform branch + physics feature branch → fusion → valid probability。
    """
    wave_in = keras.Input(shape=(input_len, n_wave_ch), name="waveform_input")

    x = layers.Conv1D(32, kernel_size=9, padding="same", activation="relu")(wave_in)
    x = layers.BatchNormalization()(x)
    x = layers.MaxPooling1D(pool_size=2)(x)

    if USE_DILATED_CNN:
        x = layers.Conv1D(64, kernel_size=5, padding="same", dilation_rate=2, activation="relu")(x)
        x = layers.BatchNormalization()(x)
        x = layers.Conv1D(64, kernel_size=5, padding="same", dilation_rate=4, activation="relu")(x)
        x = layers.BatchNormalization()(x)
    else:
        x = layers.Conv1D(64, kernel_size=5, padding="same", activation="relu")(x)
        x = layers.BatchNormalization()(x)
        x = layers.MaxPooling1D(pool_size=2)(x)

    x = layers.GlobalAveragePooling1D()(x)
    x = layers.Dropout(0.25)(x)

    feat_in = keras.Input(shape=(n_feat,), name="physics_input")
    f = layers.Dense(32, activation="relu")(feat_in)
    f = layers.BatchNormalization()(f)
    f = layers.Dropout(0.15)(f)

    h = layers.Concatenate()([x, f])
    h = layers.Dense(64, activation="relu")(h)
    h = layers.Dropout(0.40)(h)
    h = layers.Dense(16, activation="relu")(h)
    out = layers.Dense(1, activation="sigmoid", name="valid_probability")(h)

    model = keras.Model(inputs=[wave_in, feat_in], outputs=out)
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=LEARNING_RATE),
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )
    return model


def _class_weight(y_train):
    """計算簡單 class weight。"""
    y_train = np.asarray(y_train)
    n0 = np.sum(y_train == 0)
    n1 = np.sum(y_train == 1)
    total = len(y_train)
    if n0 == 0 or n1 == 0:
        return None
    return {
        0: float(total / (2.0 * n0)),
        1: float(total / (2.0 * n1)),
    }


def train_predict_one_fold_keras(Xw_train, Xf_train, y_train, Xw_test, Xf_test):
    """Keras 單一 fold 訓練與預測。"""
    # training set 只有一類時，模型無法學分類，改用常數機率。
    if len(np.unique(y_train)) < 2:
        prob = float(np.mean(y_train))
        return np.full(len(Xw_test), prob, dtype=float)

    # 只在 training set 增強正樣本
    pos_idx = np.where(y_train == 1)[0]
    Xw_aug = augment_waveforms(Xw_train[pos_idx])

    if len(Xw_aug) > 0:
        Xf_aug = np.repeat(Xf_train[pos_idx], repeats=N_AUG_POS, axis=0)
        y_aug = np.ones(len(Xw_aug), dtype=np.int32)
        Xw_train2 = np.concatenate([Xw_train, Xw_aug], axis=0)
        Xf_train2 = np.concatenate([Xf_train, Xf_aug], axis=0)
        y_train2 = np.concatenate([y_train, y_aug], axis=0)
    else:
        Xw_train2, Xf_train2, y_train2 = Xw_train, Xf_train, y_train

    perm = np.random.permutation(len(y_train2))
    Xw_train2 = Xw_train2[perm]
    Xf_train2 = Xf_train2[perm]
    y_train2 = y_train2[perm]

    scaler = StandardScaler()
    Xf_train2_s = scaler.fit_transform(Xf_train2)
    Xf_test_s = scaler.transform(Xf_test)

    keras.backend.clear_session()
    model = build_physics_guided_cnn(
        input_len=Xw_train.shape[1],
        n_wave_ch=Xw_train.shape[2],
        n_feat=Xf_train.shape[1],
    )

    callbacks = []
    # 如果資料量夠，使用少量 validation split 做 early stopping。
    validation_split = 0.0
    if len(y_train2) >= 20 and len(np.unique(y_train2)) == 2:
        validation_split = 0.15
        callbacks.append(
            keras.callbacks.EarlyStopping(
                monitor="val_loss",
                patience=10,
                restore_best_weights=True,
            )
        )

    model.fit(
        {"waveform_input": Xw_train2, "physics_input": Xf_train2_s},
        y_train2,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        class_weight=_class_weight(y_train2),
        validation_split=validation_split,
        callbacks=callbacks,
        verbose=0,
    )

    prob = model.predict(
        {"waveform_input": Xw_test, "physics_input": Xf_test_s},
        verbose=0,
    ).reshape(-1)
    return prob.astype(float)


def train_predict_one_fold_svm(Xw_train, Xf_train, y_train, Xw_test, Xf_test):
    """沒有 TensorFlow 時的 SVM fallback。"""
    if len(np.unique(y_train)) < 2:
        prob = float(np.mean(y_train))
        return np.full(len(Xw_test), prob, dtype=float)

    X_train_flat = Xw_train.reshape(len(Xw_train), -1)
    X_test_flat = Xw_test.reshape(len(Xw_test), -1)

    X_train_all = np.concatenate([X_train_flat, Xf_train], axis=1)
    X_test_all = np.concatenate([X_test_flat, Xf_test], axis=1)

    scaler = StandardScaler()
    X_train_s = scaler.fit_transform(X_train_all)
    X_test_s = scaler.transform(X_test_all)

    clf = SVC(kernel="rbf", C=1.0, probability=True, class_weight="balanced", random_state=SEED)
    clf.fit(X_train_s, y_train)
    prob = clf.predict_proba(X_test_s)[:, 1]
    return prob.astype(float)


# ============================================================
# 5. 評估與繪圖
# ============================================================

def safe_metrics(y_true, y_pred, y_prob):
    """分類評估指標。"""
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    y_prob = np.asarray(y_prob).astype(float)

    metrics = {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "mcc": matthews_corrcoef(y_true, y_pred) if len(np.unique(y_true)) == 2 else np.nan,
        "cohen_kappa": cohen_kappa_score(y_true, y_pred) if len(np.unique(y_true)) == 2 else np.nan,
        "roc_auc": np.nan,
        "pr_auc": np.nan,
    }

    if len(np.unique(y_true)) == 2 and np.all(np.isfinite(y_prob)):
        try:
            metrics["roc_auc"] = roc_auc_score(y_true, y_prob)
        except Exception:
            metrics["roc_auc"] = np.nan
        try:
            metrics["pr_auc"] = average_precision_score(y_true, y_prob)
        except Exception:
            metrics["pr_auc"] = np.nan

    return metrics



def assign_signal_category(row):
    """
    把 channel 分成較適合論文敘述的類別。

    high_confidence_valid：Teacher 與 AI 都認為 valid，建議作為主結果。
    high_confidence_invalid：Teacher 與 AI 都認為 invalid。
    ai_rescue_candidate：Teacher invalid 但 AI valid，屬於 borderline，不直接當 ground truth。
    ai_reject_candidate：Teacher valid 但 AI invalid，屬於 borderline，應人工複查。
    """
    teacher = int(row["teacher_label"])
    ai = int(row["ai_prediction"])
    prob = float(row["ai_probability"])

    if teacher == 1 and ai == 1:
        return "high_confidence_valid"
    if teacher == 0 and ai == 0:
        return "high_confidence_invalid"
    if teacher == 0 and ai == 1:
        if prob >= BORDERLINE_AI_HIGH_PROB:
            return "ai_rescue_candidate_high"
        return "ai_rescue_candidate_low"
    if teacher == 1 and ai == 0:
        if prob <= BORDERLINE_AI_LOW_PROB:
            return "ai_reject_candidate_high"
        return "ai_reject_candidate_low"
    return "unknown"

def plot_confusion_matrix_png(cm, path):
    plt.figure(figsize=(5.8, 5.2))
    plt.imshow(cm, interpolation="nearest", cmap="Blues")
    plt.title("Confusion Matrix: Teacher vs AI")
    plt.colorbar()
    tick_marks = np.arange(2)
    plt.xticks(tick_marks, ["AI Invalid", "AI Valid"])
    plt.yticks(tick_marks, ["Teacher Invalid", "Teacher Valid"])

    thresh = cm.max() / 2.0 if cm.max() > 0 else 0.5
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            plt.text(
                j,
                i,
                format(cm[i, j], "d"),
                ha="center",
                va="center",
                color="white" if cm[i, j] > thresh else "black",
                fontsize=14,
            )

    plt.ylabel("Teacher label")
    plt.xlabel("AI prediction")
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()



def build_probability_threshold_table(y_prob, step=0.1):
    """建立 AI probability 的累積統計表：每個 threshold 以上有幾個 channel。"""
    y_prob = np.asarray(y_prob, dtype=float)
    y_prob = y_prob[np.isfinite(y_prob)]
    thresholds = np.round(np.arange(0.0, 1.0 + 1e-9, step), 2)

    rows = []
    total = len(y_prob)
    for thr in thresholds:
        count = int(np.sum(y_prob >= thr))
        frac = float(count / total) if total > 0 else np.nan
        rows.append({
            "probability_threshold": float(thr),
            "n_channels_ge_threshold": count,
            "fraction_ge_threshold": frac,
        })
    return pd.DataFrame(rows)


def plot_probability_threshold_bar(prob_df, path):
    """畫出每個 AI probability threshold 以上有多少 channel 的柱狀圖。"""
    if prob_df is None or prob_df.empty:
        return

    x = prob_df["probability_threshold"].values.astype(float)
    y = prob_df["n_channels_ge_threshold"].values.astype(float)

    plt.figure(figsize=(9, 5.5))
    plt.bar([f">={v:.1f}" for v in x], y)

    offset = max(0.3, 0.01 * max(y)) if len(y) else 0.3
    for i, val in enumerate(y):
        plt.text(i, val + offset, f"{int(val)}", ha="center", va="bottom", fontsize=9)

    plt.xlabel("AI valid probability threshold")
    plt.ylabel("Number of channels")
    plt.title("Count of Channels Above Each AI Probability Threshold")
    plt.grid(True, axis="y", linestyle=":", alpha=0.5)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_probability_histogram(y_prob, path, bins=None):
    """畫出 AI probability 分布直方圖，方便看機率集中在哪些區間。"""
    y_prob = np.asarray(y_prob, dtype=float)
    y_prob = y_prob[np.isfinite(y_prob)]
    if len(y_prob) == 0:
        return

    if bins is None:
        bins = np.linspace(0, 1, 11)

    plt.figure(figsize=(8, 5.2))
    plt.hist(y_prob, bins=bins, edgecolor="black")
    plt.xlabel("AI valid probability")
    plt.ylabel("Number of channels")
    plt.title("Distribution of AI Valid Probability")
    plt.grid(True, axis="y", linestyle=":", alpha=0.5)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


# ============================================================
# 5A. 論文 / 報告用輔助圖
# ============================================================

def setup_chinese_font():
    """
    論文圖字型設定：
    - 英文與數字：Times New Roman
    - 中文：標楷體 DFKai-SB

    Matplotlib 會依照字型清單做 fallback。
    Times New Roman 沒有中文字時，會自動改用 DFKai-SB 顯示中文。
    若電腦沒有 DFKai-SB，則依序使用新細明體或微軟正黑體。
    """
    plt.rcParams["font.family"] = [
        "Times New Roman",
        "DFKai-SB",
        "PMingLiU",
        "MingLiU",
        "Microsoft JhengHei",
        "DejaVu Serif",
    ]
    plt.rcParams["font.serif"] = [
        "Times New Roman",
        "DFKai-SB",
        "PMingLiU",
        "MingLiU",
        "Microsoft JhengHei",
        "DejaVu Serif",
    ]
    plt.rcParams["mathtext.fontset"] = "stix"
    plt.rcParams["axes.unicode_minus"] = False


def _paper_dir():
    d = RESULT_DIR / "paper_figures"
    d.mkdir(exist_ok=True)
    return d


def plot_workflow_diagram(path):
    """輸出整體 HER2 FET 訊號驗證流程圖。"""
    setup_chinese_font()

    steps = [
        "原始 HER2 FET\nCSV 訊號資料",
        "排除 CH9\n參考通道",
        "自動切分 PBS 與\nHER2 濃度區間",
        "擷取各濃度\n穩態響應值",
        "計算物理特徵\nfinal drop / SNR / R²",
        "物理導向 Teacher rule\n產生 pseudo-label",
        "1D-CNN 學習\n波形與物理特徵",
        "Teacher 與 CNN\n共同認定",
        "Consensus valid channels\n建立 HER2 檢量線",
    ]

    fig, ax = plt.subplots(figsize=(10, 13))
    ax.axis("off")

    y_positions = np.linspace(0.92, 0.08, len(steps))
    x = 0.5

    for i, (step, y) in enumerate(zip(steps, y_positions)):
        ax.text(
            x, y, step,
            ha="center", va="center",
            fontsize=13,
            bbox=dict(boxstyle="round,pad=0.55", facecolor="white", edgecolor="black", linewidth=1.4),
            transform=ax.transAxes,
        )
        if i < len(steps) - 1:
            ax.annotate(
                "",
                xy=(x, y_positions[i + 1] + 0.04),
                xytext=(x, y - 0.04),
                xycoords=ax.transAxes,
                arrowprops=dict(arrowstyle="->", linewidth=1.5),
            )

    ax.set_title("HER2 FET 生物感測訊號品質驗證流程", fontsize=18, pad=18)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_teacher_rule_flowchart(path):
    """輸出物理導向 Teacher rule 判斷流程圖。"""
    setup_chinese_font()

    fig, ax = plt.subplots(figsize=(12, 10))
    ax.axis("off")

    boxes = [
        (0.50, 0.91, "單一 sensing channel\n穩態響應與物理特徵"),
        (0.50, 0.78, f"Gate 1：訊號強度\nfinal_drop > {SIGNAL_THRESHOLD:g}"),
        (0.50, 0.65, f"Gate 2：PBS noise / SNR\nfinal_drop ≥ {SNR_THRESHOLD_FOR_LABEL:g} × PBS_std"),
        (0.50, 0.52, "Gate 3：反應方向\nslope > 0"),
        (0.50, 0.39, f"Gate 4：濃度趨勢\nmonotonicity score ≥ {MONOTONICITY_SCORE_THRESHOLD:g}\n且反向步數 ≤ {MAX_REVERSE_STEPS_FOR_VALID}"),
        (0.50, 0.24, f"Gate 5：檢量線相關性\nlinear R² 或 log R² ≥ {R2_THRESHOLD:g}"),
        (0.50, 0.09, "High-confidence valid\n作為 CNN teacher pseudo-label"),
    ]

    for i, (x, y, txt) in enumerate(boxes):
        ax.text(
            x, y, txt,
            ha="center", va="center",
            fontsize=12.5,
            bbox=dict(boxstyle="round,pad=0.55", facecolor="white", edgecolor="black", linewidth=1.4),
            transform=ax.transAxes,
        )
        if i < len(boxes) - 1:
            ax.annotate(
                "",
                xy=(x, boxes[i + 1][1] + 0.055),
                xytext=(x, y - 0.055),
                xycoords=ax.transAxes,
                arrowprops=dict(arrowstyle="->", linewidth=1.5),
            )

    ax.text(
        0.82, 0.58,
        "任一條件未通過\n→ invalid / borderline\n→ 不直接進入主檢量線",
        ha="center", va="center",
        fontsize=12,
        bbox=dict(boxstyle="round,pad=0.45", facecolor="white", edgecolor="gray", linestyle="--"),
        transform=ax.transAxes,
    )

    ax.set_title("物理導向 Teacher rule 之通道篩選邏輯", fontsize=18, pad=18)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_channel_selection_summary(out_df, path):
    """輸出多通道篩選數量統計圖。"""
    setup_chinese_font()

    teacher_valid = int((out_df["teacher_label"] == 1).sum())
    ai_valid = int((out_df["ai_prediction"] == 1).sum())
    consensus = int(((out_df["teacher_label"] == 1) & (out_df["ai_prediction"] == 1)).sum())
    ai_rescue = int(((out_df["teacher_label"] == 0) & (out_df["ai_prediction"] == 1)).sum())
    ai_reject = int(((out_df["teacher_label"] == 1) & (out_df["ai_prediction"] == 0)).sum())

    labels = [
        "全部通道",
        "Teacher\n有效通道",
        "CNN\n有效通道",
        "共識有效\n主結果",
        "AI rescue\n邊界通道",
        "AI rejection\n邊界通道",
    ]
    counts = [len(out_df), teacher_valid, ai_valid, consensus, ai_rescue, ai_reject]

    plt.figure(figsize=(10, 5.8))
    bars = plt.bar(labels, counts)
    for b, c in zip(bars, counts):
        plt.text(b.get_x() + b.get_width() / 2, c + max(0.5, 0.015 * max(counts)), str(c),
                 ha="center", va="bottom", fontsize=12)

    plt.ylabel("通道數量")
    plt.title("多通道訊號篩選結果統計")
    plt.grid(True, axis="y", linestyle=":", alpha=0.5)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_representative_waveforms_composite(X_wave, out_df, path):
    """
    輸出 2x2 代表性波形：
    共識有效、低響應無效、非單調無效、邊界候選。
    """
    setup_chinese_font()

    def pick_idx(mask):
        idxs = np.where(mask)[0]
        return int(idxs[0]) if len(idxs) else None

    teacher = out_df["teacher_label"].values.astype(int)
    ai = out_df["ai_prediction"].values.astype(int)
    reasons = out_df["teacher_reason"].astype(str).values

    idx_consensus = pick_idx((teacher == 1) & (ai == 1))
    idx_low = pick_idx((teacher == 0) & (ai == 0) & np.array(["low_signal" in r for r in reasons]))
    idx_nonmono = pick_idx((teacher == 0) & (ai == 0) & np.array(["non_monotonic" in r for r in reasons]))
    idx_border = pick_idx(teacher != ai)

    picks = [
        ("(a) 共識有效訊號", idx_consensus),
        ("(b) 低響應無效訊號", idx_low),
        ("(c) 非單調無效訊號", idx_nonmono),
        ("(d) 邊界候選訊號", idx_border),
    ]

    fig, axes = plt.subplots(2, 2, figsize=(13, 8.5))
    axes = axes.reshape(-1)

    for ax, (title, idx) in zip(axes, picks):
        if idx is None:
            ax.text(0.5, 0.5, "無對應範例", ha="center", va="center", transform=ax.transAxes)
            ax.set_title(title)
            ax.axis("off")
            continue

        wave = X_wave[idx]
        meta = out_df.iloc[idx].to_dict()
        phases = build_phases(meta.get("phase_duration_seconds", DEFAULT_PHASE_DURATION_SECONDS))
        total_end = phases[-1]["end"]
        x = np.linspace(0, total_end, len(wave))

        ax.plot(x, wave[:, 0], label="raw-normalized", linewidth=1.2)
        ax.plot(x, wave[:, 1], label="z-score", linewidth=1.0, alpha=0.8)
        ax.plot(x, wave[:, 2], label="derivative", linewidth=0.9, alpha=0.7)

        for ph in phases:
            ax.axvline(ph["end"], linestyle=":", linewidth=0.7, alpha=0.5)

        ax.set_title(
            f"{title}\n{Path(meta['file']).name} CH{meta['channel']} | "
            f"T={int(meta['teacher_label'])}, AI={int(meta['ai_prediction'])}, "
            f"p={float(meta['ai_probability']):.2f}",
            fontsize=10,
        )
        ax.set_xlabel("時間 (s)")
        ax.set_ylabel("正規化訊號")
        ax.grid(True, linestyle=":", alpha=0.4)
        ax.legend(fontsize=8, loc="best")

    fig.suptitle("不同訊號品質類型之代表性時域波形", fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_final_drop_vs_noise(out_df, path):
    """輸出 final_drop 與 PBS noise 關係圖，用於解釋 3×PBS_std 門檻。"""
    setup_chinese_font()

    df = out_df.copy()
    x = pd.to_numeric(df.get("pbs_std"), errors="coerce")
    y = pd.to_numeric(df.get("final_drop"), errors="coerce")
    mask = np.isfinite(x) & np.isfinite(y)
    df = df.loc[mask].copy()
    x = x[mask]
    y = y[mask]

    plt.figure(figsize=(8, 6))
    categories = [
        ("共識有效", (df["teacher_label"] == 1) & (df["ai_prediction"] == 1), "o"),
        ("邊界候選", (df["teacher_label"] != df["ai_prediction"]), "s"),
        ("無效通道", (df["teacher_label"] == 0) & (df["ai_prediction"] == 0), "x"),
    ]

    for label, m, marker in categories:
        plt.scatter(x[m], y[m], label=label, marker=marker, alpha=0.8)

    if len(x) > 0:
        x_line = np.linspace(0, max(float(np.nanmax(x)), 1e-9), 100)
        plt.plot(x_line, SNR_THRESHOLD_FOR_LABEL * x_line, linestyle="--",
                 label=f"final_drop = {SNR_THRESHOLD_FOR_LABEL:g} × PBS_std")
        plt.axhline(SIGNAL_THRESHOLD, linestyle=":", label=f"固定訊號門檻 = {SIGNAL_THRESHOLD:g}")

    plt.xlabel("PBS baseline noise (PBS_std)")
    plt.ylabel("final_drop")
    plt.title("訊號響應幅度與 PBS baseline noise 之關係")
    plt.grid(True, linestyle=":", alpha=0.5)
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_monotonicity_distribution(out_df, path):
    """輸出 monotonicity score 分布圖。"""
    setup_chinese_font()

    df = out_df.copy()
    values = pd.to_numeric(df.get("monotonicity_score"), errors="coerce")
    values = values[np.isfinite(values)]

    plt.figure(figsize=(8, 5.5))
    plt.hist(values, bins=np.linspace(0, 1, 11), edgecolor="black", alpha=0.8)
    plt.axvline(MONOTONICITY_SCORE_THRESHOLD, linestyle="--",
                label=f"門檻 = {MONOTONICITY_SCORE_THRESHOLD:g}")
    plt.xlabel("monotonicity score")
    plt.ylabel("通道數量")
    plt.title("不同通道之 monotonicity score 分布")
    plt.grid(True, axis="y", linestyle=":", alpha=0.5)
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_linear_vs_log_r2(out_df, path):
    """輸出 linear R² 與 log R² 比較圖。"""
    setup_chinese_font()

    df = out_df.copy()
    x = pd.to_numeric(df.get("r2"), errors="coerce")
    y = pd.to_numeric(df.get("log_r2"), errors="coerce")
    mask = np.isfinite(x) & np.isfinite(y)
    df = df.loc[mask].copy()
    x = x[mask]
    y = y[mask]

    plt.figure(figsize=(7.5, 6.5))
    categories = [
        ("共識有效", (df["teacher_label"] == 1) & (df["ai_prediction"] == 1), "o"),
        ("邊界候選", (df["teacher_label"] != df["ai_prediction"]), "s"),
        ("無效通道", (df["teacher_label"] == 0) & (df["ai_prediction"] == 0), "x"),
    ]

    for label, m, marker in categories:
        plt.scatter(x[m], y[m], label=label, marker=marker, alpha=0.8)

    plt.axvline(R2_THRESHOLD, linestyle="--", label=f"linear R² 門檻 = {R2_THRESHOLD:g}")
    plt.axhline(R2_THRESHOLD, linestyle=":", label=f"log R² 門檻 = {R2_THRESHOLD:g}")
    plt.xlabel("linear calibration R²")
    plt.ylabel("log calibration R²")
    plt.title("線性濃度與對數濃度擬合 R² 比較")
    plt.grid(True, linestyle=":", alpha=0.5)
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def _calibration_row_for_indices(indices, all_calib_dfs, name):
    data_list = [all_calib_dfs[int(i)] for i in indices]
    return analyze_calibration(data_list, name)


def run_threshold_sensitivity(out_df, all_calib_dfs):
    """
    簡易門檻敏感度分析：
    1. R² threshold sweep：觀察 valid channel 數與 log R²
    2. SNR threshold sweep：觀察 valid channel 數與 log R²
    3. AI probability threshold sweep：觀察 AI valid 數與 log R²
    """
    rows = []

    df = out_df.copy()
    final_drop = pd.to_numeric(df["final_drop"], errors="coerce").values
    pbs_std = pd.to_numeric(df["pbs_std"], errors="coerce").values
    snr = pd.to_numeric(df["snr"], errors="coerce").values
    slope = pd.to_numeric(df["slope"], errors="coerce").values
    mono = pd.to_numeric(df["monotonicity_score"], errors="coerce").values
    reverse = pd.to_numeric(df["num_reverse_steps"], errors="coerce").values
    linear_r2 = pd.to_numeric(df["r2"], errors="coerce").values
    log_r2 = pd.to_numeric(df["log_r2"], errors="coerce").values
    best_r2 = np.nanmax(np.vstack([linear_r2, log_r2]), axis=0)
    ai_prob = pd.to_numeric(df["ai_probability"], errors="coerce").values

    # 共用基本條件：訊號方向、訊號大小、單調性
    signal_gate = np.isfinite(final_drop) & (final_drop >= SIGNAL_THRESHOLD)
    if USE_NOISE_ADAPTIVE_SIGNAL_GATE:
        noise_gate = np.ones(len(df), dtype=bool)
        ok_noise = np.isfinite(pbs_std) & (pbs_std > 0)
        noise_gate[ok_noise] = final_drop[ok_noise] >= (SNR_THRESHOLD_FOR_LABEL * pbs_std[ok_noise])
        signal_gate = signal_gate & noise_gate

    base_gate = (
        signal_gate
        & np.isfinite(slope) & (slope > 0)
        & np.isfinite(mono) & (mono >= MONOTONICITY_SCORE_THRESHOLD)
        & np.isfinite(reverse) & (reverse <= MAX_REVERSE_STEPS_FOR_VALID)
    )

    for thr in np.arange(0.50, 0.96, 0.05):
        idxs = np.where(base_gate & np.isfinite(best_r2) & (best_r2 >= thr))[0]
        row = _calibration_row_for_indices(idxs, all_calib_dfs, f"R2_threshold_{thr:.2f}")
        rows.append({
            "sweep_type": "r2_threshold",
            "threshold": float(round(thr, 2)),
            **row,
        })

    # SNR sweep：這裡固定方向、monotonicity、R²，改變 SNR 門檻
    r2_gate = np.isfinite(best_r2) & (best_r2 >= R2_THRESHOLD)
    basic_without_snr = (
        np.isfinite(final_drop) & (final_drop >= SIGNAL_THRESHOLD)
        & np.isfinite(slope) & (slope > 0)
        & np.isfinite(mono) & (mono >= MONOTONICITY_SCORE_THRESHOLD)
        & np.isfinite(reverse) & (reverse <= MAX_REVERSE_STEPS_FOR_VALID)
        & r2_gate
    )

    for thr in np.arange(1.0, 5.1, 0.5):
        idxs = np.where(basic_without_snr & np.isfinite(snr) & (snr >= thr))[0]
        row = _calibration_row_for_indices(idxs, all_calib_dfs, f"SNR_threshold_{thr:.1f}")
        rows.append({
            "sweep_type": "snr_threshold",
            "threshold": float(round(thr, 2)),
            **row,
        })

    for thr in np.arange(0.10, 0.96, 0.05):
        idxs = np.where(np.isfinite(ai_prob) & (ai_prob >= thr))[0]
        row = _calibration_row_for_indices(idxs, all_calib_dfs, f"AI_prob_threshold_{thr:.2f}")
        rows.append({
            "sweep_type": "ai_probability_threshold",
            "threshold": float(round(thr, 2)),
            **row,
        })

    return pd.DataFrame(rows)


def plot_threshold_sensitivity(sens_df, path):
    """輸出門檻敏感度分析圖：valid channel 數與 log R²。"""
    setup_chinese_font()

    if sens_df is None or sens_df.empty:
        return

    labels = {
        "r2_threshold": "R² 門檻",
        "snr_threshold": "SNR 門檻",
        "ai_probability_threshold": "AI 機率門檻",
    }

    fig, axes = plt.subplots(3, 1, figsize=(9, 12), sharex=False)

    for ax, sweep_type in zip(axes, ["r2_threshold", "snr_threshold", "ai_probability_threshold"]):
        sub = sens_df[sens_df["sweep_type"] == sweep_type].copy()
        if sub.empty:
            ax.axis("off")
            continue

        x = sub["threshold"].values.astype(float)
        n = sub["n_channels"].values.astype(float)
        log_r2 = sub["log_calibration_r2"].values.astype(float)

        ax.plot(x, n, marker="o", label="有效通道數")
        ax.set_ylabel("有效通道數")
        ax.grid(True, linestyle=":", alpha=0.5)

        ax2 = ax.twinx()
        ax2.plot(x, log_r2, marker="s", linestyle="--", label="log 檢量線 R²")
        ax2.set_ylabel("log 檢量線 R²")
        ax.set_title(labels.get(sweep_type, sweep_type))

        # 合併 legend
        lines1, labs1 = ax.get_legend_handles_labels()
        lines2, labs2 = ax2.get_legend_handles_labels()
        ax.legend(lines1 + lines2, labs1 + labs2, loc="best")

    axes[-1].set_xlabel("門檻值")
    fig.suptitle("不同篩選門檻對檢量線結果之影響", fontsize=16)
    plt.tight_layout(rect=[0, 0, 1, 0.97])
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def _choose_representative_indices_for_paper(out_df):
    """
    選出較適合放論文的代表性通道。
    不再只抓第一個，而是依照品質特徵挑比較有代表性的案例。
    """
    df = out_df.copy()
    df["_idx"] = np.arange(len(df))

    m_consensus = (df["teacher_label"] == 1) & (df["ai_prediction"] == 1)
    if m_consensus.any():
        sub = df[m_consensus].copy()
        for c in ["quality_score", "log_r2", "ai_probability"]:
            sub[c] = pd.to_numeric(sub[c], errors="coerce").fillna(-np.inf)
        idx_consensus = int(sub.sort_values(["quality_score", "log_r2", "ai_probability"], ascending=False).iloc[0]["_idx"])
    else:
        idx_consensus = None

    reason = df["teacher_reason"].astype(str)
    m_low = (df["teacher_label"] == 0) & (df["ai_prediction"] == 0) & reason.str.contains("low_signal", case=False, na=False)
    if m_low.any():
        sub = df[m_low].copy()
        sub["final_drop_abs"] = pd.to_numeric(sub["final_drop"], errors="coerce").abs()
        idx_low = int(sub.sort_values("final_drop_abs", ascending=True).iloc[0]["_idx"])
    else:
        idx_low = None

    m_nonmono = (df["teacher_label"] == 0) & reason.str.contains("non_monotonic", case=False, na=False)
    if m_nonmono.any():
        sub = df[m_nonmono].copy()
        sub["monotonicity_score"] = pd.to_numeric(sub["monotonicity_score"], errors="coerce").fillna(1.0)
        idx_nonmono = int(sub.sort_values("monotonicity_score", ascending=True).iloc[0]["_idx"])
    else:
        idx_nonmono = None

    m_border = df["teacher_label"] != df["ai_prediction"]
    if m_border.any():
        sub = df[m_border].copy()
        sub["prob_distance"] = (pd.to_numeric(sub["ai_probability"], errors="coerce") - 0.5).abs()
        idx_border = int(sub.sort_values("prob_distance", ascending=False).iloc[0]["_idx"])
    else:
        idx_border = None

    return [
        ("(a) 共識有效訊號", idx_consensus),
        ("(b) 低響應無效訊號", idx_low),
        ("(c) 非單調無效訊號", idx_nonmono),
        ("(d) 邊界候選訊號", idx_border),
    ]


def plot_representative_raw_drop_composite(out_df, all_calib_dfs, path):
    """
    論文主文建議使用的代表性波形圖。

    每一列是一種訊號品質類型：
    左圖：baseline-relative time response，也就是 PBS baseline - DeltaId
    右圖：該 channel 的 steady-state Drop vs concentration

    這比 raw-normalized / z-score / derivative 疊圖更直觀，適合跟教授解釋。
    """
    setup_chinese_font()

    picks = _choose_representative_indices_for_paper(out_df)

    fig, axes = plt.subplots(4, 2, figsize=(14, 15))
    selected_rows = []

    for row_i, (category_title, idx) in enumerate(picks):
        ax_time = axes[row_i, 0]
        ax_drop = axes[row_i, 1]

        if idx is None:
            ax_time.text(0.5, 0.5, "無對應範例", ha="center", va="center", transform=ax_time.transAxes)
            ax_drop.text(0.5, 0.5, "無對應範例", ha="center", va="center", transform=ax_drop.transAxes)
            ax_time.set_title(category_title)
            ax_drop.set_title(category_title)
            continue

        meta = out_df.iloc[idx].to_dict()
        fpath = meta["file"]
        channel = int(meta["channel"])
        phase_duration = int(meta.get("phase_duration_seconds", DEFAULT_PHASE_DURATION_SECONDS))
        phases = build_phases(phase_duration)

        selected_rows.append({
            "category": category_title,
            "index": idx,
            "file": Path(fpath).name,
            "channel": channel,
            "teacher_label": int(meta["teacher_label"]),
            "ai_prediction": int(meta["ai_prediction"]),
            "ai_probability": float(meta["ai_probability"]),
            "teacher_reason": meta["teacher_reason"],
            "signal_category": meta.get("signal_category", ""),
        })

        df_raw = read_csv_smart(fpath)
        if df_raw is not None and not df_raw.empty:
            ch_data = df_raw[df_raw["Channel"].astype(int) == channel].copy()
            ch_data = ch_data.sort_values("Interval")

            calib = all_calib_dfs[idx].copy()
            if len(calib) > 0 and "MeanDeltaId" in calib.columns:
                pbs_row = calib[calib["Conc"] == 0]
                if len(pbs_row) > 0:
                    baseline = float(pbs_row["MeanDeltaId"].iloc[0])
                else:
                    baseline = float(ch_data["DeltaId"].iloc[:max(5, int(len(ch_data) * 0.1))].mean())
            else:
                baseline = float(ch_data["DeltaId"].iloc[:max(5, int(len(ch_data) * 0.1))].mean())

            response = baseline - ch_data["DeltaId"].values.astype(float)
            t = ch_data["Interval"].values.astype(float)

            ax_time.plot(t, response, linewidth=1.1)
            ax_time.axhline(0, linestyle="--", linewidth=0.8)

            y_min, y_max = np.nanmin(response), np.nanmax(response)
            y_text = y_max - 0.08 * (y_max - y_min + 1e-12)
            prev_end = 0.0
            for ph in phases:
                ax_time.axvline(ph["end"], linestyle=":", linewidth=0.8, alpha=0.8)
                mid = (prev_end + ph["end"]) / 2.0
                ax_time.text(mid, y_text, ph["name"], ha="center", va="top", fontsize=8, rotation=0)
                steady_start = ph["end"] - STEADY_WINDOW_SECONDS
                ax_time.axvspan(steady_start, ph["end"], alpha=0.08)
                prev_end = ph["end"]

            ax_time.set_xlabel("時間 (s)")
            ax_time.set_ylabel("基準化響應\n(PBS baseline - DeltaId)")
            ax_time.grid(True, linestyle=":", alpha=0.45)
        else:
            ax_time.text(0.5, 0.5, "無法讀取原始 CSV", ha="center", va="center", transform=ax_time.transAxes)

        ax_time.set_title(
            f"{category_title}\n{Path(fpath).name} CH{channel} | "
            f"T={int(meta['teacher_label'])}, AI={int(meta['ai_prediction'])}, "
            f"p={float(meta['ai_probability']):.2f}",
            fontsize=10.5,
        )

        calib = all_calib_dfs[idx].copy()
        if calib is not None and len(calib) > 0:
            x = calib["Conc"].values.astype(float)
            y = calib["Drop"].values.astype(float)
            labels = calib["Phase"].astype(str).values if "Phase" in calib.columns else [str(v) for v in x]

            ax_drop.plot(x, y, marker="o", linewidth=1.4)
            ax_drop.axhline(0, linestyle="--", linewidth=0.8)

            for xi, yi, lab in zip(x, y, labels):
                ax_drop.text(xi, yi, f" {lab}", fontsize=8, va="bottom")

            r2 = meta.get("r2", np.nan)
            log_r2 = meta.get("log_r2", np.nan)
            final_drop = meta.get("final_drop", np.nan)
            snr = meta.get("snr", np.nan)
            info = (
                f"linear R²={r2:.2f}\n"
                f"log R²={log_r2:.2f}\n"
                f"final_drop={final_drop:.3g}\n"
                f"SNR={snr:.2f}"
            )
            ax_drop.text(
                0.03, 0.97, info,
                ha="left", va="top",
                transform=ax_drop.transAxes,
                fontsize=9,
                bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="gray", alpha=0.9),
            )

            ax_drop.set_xlabel("HER2 濃度 (ng/mL)")
            ax_drop.set_ylabel("穩態 Drop\n(PBS baseline - mean DeltaId)")
            ax_drop.grid(True, linestyle=":", alpha=0.45)
        else:
            ax_drop.text(0.5, 0.5, "無穩態資料", ha="center", va="center", transform=ax_drop.transAxes)

        ax_drop.set_title("各濃度穩態響應點", fontsize=10.5)

    fig.suptitle("不同訊號品質類型之代表性波形與穩態響應", fontsize=18)
    plt.tight_layout(rect=[0, 0, 1, 0.975])
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()

    selected_df = pd.DataFrame(selected_rows)
    safe_to_csv(selected_df, _paper_dir() / "fig04_selected_representative_channels.csv", index=False, encoding="utf-8-sig")

def save_paper_figures(X_wave, out_df, y, y_pred, y_prob, all_calib_dfs):
    """集中輸出論文 / 報告用圖。"""
    d = _paper_dir()

    plot_workflow_diagram(d / "fig01_signal_validation_workflow.png")
    plot_channel_selection_summary(out_df, d / "fig02_channel_selection_summary.png")
    plot_teacher_rule_flowchart(d / "fig03_teacher_rule_flowchart.png")

    # 主文建議使用：原始 / baseline-relative 時域響應 + 穩態 Drop 點圖
    plot_representative_raw_drop_composite(out_df, all_calib_dfs, d / "fig04_representative_waveforms_raw_drop.png")

    # 補充資料可用：CNN 實際輸入的三通道特徵波形
    plot_representative_waveforms_composite(X_wave, out_df, d / "fig04b_cnn_input_waveforms_supplementary.png")

    # 既有 calibration comparison 會另存一份到 paper_figures 方便找
    all_calib = all_calib_dfs
    teacher_calib = [all_calib_dfs[i] for i in range(len(y)) if y[i] == 1]
    ai_calib = [all_calib_dfs[i] for i in range(len(y_pred)) if y_pred[i] == 1]
    consensus_calib = [all_calib_dfs[i] for i in range(len(y)) if y[i] == 1 and y_pred[i] == 1]
    ai_rescue_calib = [all_calib_dfs[i] for i in range(len(y)) if y[i] == 0 and y_pred[i] == 1]

    recommended_sets = [
        ("全部通道", all_calib),
        ("Teacher 有效通道", teacher_calib),
        ("CNN 有效通道", ai_calib),
        ("共識有效通道", consensus_calib),
        ("AI rescue 邊界通道", ai_rescue_calib),
    ]

    plot_calibration_multi(
        recommended_sets,
        d / "fig05a_calibration_linear_scale.png",
        "訊號驗證前後之 HER2 線性濃度檢量線比較",
        log_x=False,
    )
    plot_calibration_multi(
        recommended_sets,
        d / "fig05b_calibration_log_scale.png",
        "訊號驗證前後之 HER2 對數濃度檢量線比較",
        log_x=True,
    )

    plot_probability_histogram(y_prob, d / "fig06_ai_probability_histogram.png")
    prob_threshold_df = build_probability_threshold_table(y_prob, step=0.1)
    plot_probability_threshold_bar(prob_threshold_df, d / "fig06b_ai_probability_threshold_counts.png")

    # 門檻合理性解釋圖
    plot_final_drop_vs_noise(out_df, d / "fig07_final_drop_vs_pbs_noise.png")
    plot_monotonicity_distribution(out_df, d / "fig08_monotonicity_score_distribution.png")
    plot_linear_vs_log_r2(out_df, d / "fig09_linear_vs_log_r2.png")

    sens_df = run_threshold_sensitivity(out_df, all_calib_dfs)
    safe_to_csv(sens_df, d / "threshold_sensitivity_analysis.csv", index=False, encoding="utf-8-sig")
    plot_threshold_sensitivity(sens_df, d / "fig10_threshold_sensitivity_analysis.png")

    print(f"\n論文 / 報告用圖已輸出至：{d.resolve()}")

def get_calibration_stats(calib_list):
    if len(calib_list) == 0:
        return pd.DataFrame(columns=["Conc", "mean", "std", "count"])
    df = pd.concat(calib_list, ignore_index=True)
    stats = df.groupby("Conc")["Drop"].agg(["mean", "std", "count"]).reset_index()
    stats["std"] = stats["std"].fillna(0.0)
    return stats


def analyze_calibration(calib_list, name):
    """計算 linear / log calibration curve 的 R²、sensitivity、LOD、CV。"""
    row = {
        "method": name,
        "n_channels": len(calib_list),
        "sensitivity_slope": np.nan,
        "intercept": np.nan,
        "calibration_r2": np.nan,
        "log_sensitivity_slope": np.nan,
        "log_intercept": np.nan,
        "log_calibration_r2": np.nan,
        "lod_estimated": np.nan,
        "mean_cv_nonzero": np.nan,
        "mean_errorbar_nonzero": np.nan,
    }
    if len(calib_list) == 0:
        return row

    stats = get_calibration_stats(calib_list)
    if len(stats) < 2:
        return row

    x = stats["Conc"].values.astype(float)
    y = stats["mean"].values.astype(float)
    slope, intercept, r2 = _safe_linear_fit(x, y)
    log_slope, log_intercept, log_r2 = _safe_log_concentration_fit(x, y)

    all_df = pd.concat(calib_list, ignore_index=True)
    pbs_rows = all_df[all_df["Conc"] == 0]
    if len(pbs_rows) > 0 and "PBS_std" in pbs_rows:
        blank_std = float(pbs_rows["PBS_std"].mean())
    else:
        blank_std = np.nan

    lod = np.nan
    if np.isfinite(blank_std) and np.isfinite(slope) and abs(slope) > 1e-12:
        lod = float(3.0 * blank_std / abs(slope))

    nonzero = stats[stats["Conc"] > 0].copy()
    cvs = []
    for _, r in nonzero.iterrows():
        if abs(r["mean"]) > 1e-12:
            cvs.append(abs(r["std"] / r["mean"]))

    row.update({
        "sensitivity_slope": slope,
        "intercept": intercept,
        "calibration_r2": r2,
        "log_sensitivity_slope": log_slope,
        "log_intercept": log_intercept,
        "log_calibration_r2": log_r2,
        "lod_estimated": lod,
        "mean_cv_nonzero": float(np.mean(cvs)) if len(cvs) else np.nan,
        "mean_errorbar_nonzero": float(nonzero["std"].mean()) if len(nonzero) else np.nan,
    })
    return row


def plot_calibration_comparison(all_calib, rule_calib, ai_calib, path):
    plt.figure(figsize=(9, 6))

    configs = [
        ("All channels", all_calib, "o", "-"),
        ("Rule-based valid", rule_calib, "s", "--"),
        ("AI-assisted valid", ai_calib, "^", "-"),
    ]

    for label, data_list, marker, linestyle in configs:
        if len(data_list) == 0:
            continue
        stats = get_calibration_stats(data_list)
        stats = stats[stats["Conc"] > 0]
        if len(stats) == 0:
            continue
        x = stats["Conc"].values.astype(float)
        y = stats["mean"].values.astype(float)
        err = stats["std"].values.astype(float)
        plt.errorbar(
            x,
            y,
            yerr=err,
            fmt=marker,
            linestyle=linestyle,
            capsize=5,
            linewidth=1.8,
            markersize=6,
            label=f"{label} (N={len(data_list)})",
        )

    plt.xlabel("HER2 concentration (ng/mL)", fontsize=13)
    plt.ylabel("Delta ID drop", fontsize=13)
    plt.title("HER2 FET-Based Biosensor Calibration Curve Comparison", fontsize=15)
    plt.grid(True, linestyle=":", alpha=0.7)
    plt.legend(fontsize=11)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()


def plot_log_calibration_comparison(all_calib, rule_calib, ai_calib, path):
    """畫 x 軸為 log scale 的 calibration comparison。PBS = 0 會被排除。"""
    plt.figure(figsize=(9, 6))

    configs = [
        ("All channels", all_calib, "o", "-"),
        ("Rule-based valid", rule_calib, "s", "--"),
        ("AI-assisted valid", ai_calib, "^", "-"),
    ]

    for label, data_list, marker, linestyle in configs:
        if len(data_list) == 0:
            continue
        stats = get_calibration_stats(data_list)
        stats = stats[stats["Conc"] > 0]
        if len(stats) == 0:
            continue

        x = stats["Conc"].values.astype(float)
        y = stats["mean"].values.astype(float)
        err = stats["std"].values.astype(float)

        plt.errorbar(
            x,
            y,
            yerr=err,
            fmt=marker,
            linestyle=linestyle,
            capsize=5,
            linewidth=1.8,
            markersize=6,
            label=f"{label} (N={len(data_list)})",
        )

        # 額外畫出 log-domain 線性擬合趨勢線，方便比較 log_R² 的意義。
        log_slope, log_intercept, log_r2 = _safe_log_concentration_fit(x, y)
        if np.isfinite(log_slope) and np.isfinite(log_intercept):
            x_fit = np.logspace(np.log10(np.min(x)), np.log10(np.max(x)), 100)
            y_fit = log_slope * np.log10(x_fit) + log_intercept
            plt.plot(x_fit, y_fit, linestyle=linestyle, linewidth=1.2, alpha=0.7)

    plt.xscale("log")
    plt.xlabel("HER2 concentration (ng/mL, log scale)", fontsize=13)
    plt.ylabel("Delta ID drop", fontsize=13)
    plt.title("HER2 FET-Based Biosensor Log-Scale Calibration Curve", fontsize=15)
    plt.grid(True, which="both", linestyle=":", alpha=0.7)
    plt.legend(fontsize=11)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()



def plot_calibration_multi(calib_sets, path, title, log_x=False):
    """
    更通用的 calibration 圖。
    calib_sets: list of (label, calib_list)
    log_x=True 時，PBS = 0 會自動排除，並加上 log-domain trend line。
    """
    plt.figure(figsize=(9.5, 6.2))
    markers = ["o", "s", "^", "D", "v", "P", "X"]
    linestyles = ["-", "--", "-.", ":", "-", "--", "-."]

    for k, (label, data_list) in enumerate(calib_sets):
        if len(data_list) == 0:
            continue
        stats = get_calibration_stats(data_list)
        stats = stats[stats["Conc"] > 0]
        if len(stats) == 0:
            continue

        x = stats["Conc"].values.astype(float)
        y = stats["mean"].values.astype(float)
        err = stats["std"].values.astype(float)
        marker = markers[k % len(markers)]
        linestyle = linestyles[k % len(linestyles)]

        plt.errorbar(
            x,
            y,
            yerr=err,
            fmt=marker,
            linestyle=linestyle,
            capsize=5,
            linewidth=1.6,
            markersize=5.5,
            label=f"{label} (N={len(data_list)})",
        )

        if log_x:
            log_slope, log_intercept, log_r2 = _safe_log_concentration_fit(x, y)
            if np.isfinite(log_slope) and np.isfinite(log_intercept):
                x_fit = np.logspace(np.log10(np.min(x)), np.log10(np.max(x)), 100)
                y_fit = log_slope * np.log10(x_fit) + log_intercept
                plt.plot(x_fit, y_fit, linestyle=linestyle, linewidth=1.1, alpha=0.65)

    if log_x:
        plt.xscale("log")
        plt.xlabel("HER2 concentration (ng/mL, log scale)", fontsize=13)
        plt.grid(True, which="both", linestyle=":", alpha=0.7)
    else:
        plt.xlabel("HER2 concentration (ng/mL)", fontsize=13)
        plt.grid(True, linestyle=":", alpha=0.7)

    plt.ylabel("Delta ID drop", fontsize=13)
    plt.title(title, fontsize=15)
    plt.legend(fontsize=10)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.close()

def plot_one_waveform(wave, meta, path, title_extra="", phases=None):
    """畫單一 channel 的三通道波形。"""
    if phases is None:
        phase_duration = meta.get("phase_duration_seconds", DEFAULT_PHASE_DURATION_SECONDS)
        phases = build_phases(phase_duration)

    total_end = phases[-1]["end"]
    x = np.linspace(0, total_end, len(wave))

    plt.figure(figsize=(10, 5))
    plt.plot(x, wave[:, 0], label="raw-normalized", linewidth=1.2)
    plt.plot(x, wave[:, 1], label="z-score", linewidth=1.2, alpha=0.8)
    plt.plot(x, wave[:, 2], label="derivative", linewidth=1.0, alpha=0.7)

    for ph in phases:
        plt.axvline(ph["end"], linestyle=":", linewidth=0.8, alpha=0.6)
        plt.text(ph["end"], plt.ylim()[1] * 0.9, ph["name"], rotation=90, fontsize=8, va="top")

    title = f"{Path(meta['file']).name} - CH{meta['channel']}"
    if title_extra:
        title += f" | {title_extra}"
    plt.title(title)
    plt.xlabel("Time (s)")
    plt.ylabel("Normalized signal")
    plt.grid(True, linestyle=":", alpha=0.5)
    plt.legend(fontsize=9)
    plt.tight_layout()
    plt.savefig(path, dpi=200, bbox_inches="tight")
    plt.close()


# ============================================================
# 6. 主流程
# ============================================================

def collect_dataset():
    csv_files = []
    for f in sorted(glob.glob(CSV_GLOB)):
        base = os.path.basename(f)
        if base.startswith(EXCLUDE_PREFIXES):
            continue
        if str(RESULT_DIR) in f:
            continue
        csv_files.append(f)

    print("\n[階段 1] 掃描 CSV 檔案")
    print(f"找到 {len(csv_files)} 個 CSV 檔。")

    all_waveforms = []
    all_features = []
    all_labels = []
    all_meta = []
    all_calib_dfs = []

    for fpath in csv_files:
        df = read_csv_smart(fpath)
        if df is None or df.empty:
            print(f"  [警告] 無法讀取或缺少必要欄位：{fpath}")
            continue

        phases, phase_duration = get_phases_for_file(df)
        channels = sorted(df["Channel"].dropna().unique())
        kept_channels = [ch for ch in channels if int(ch) not in EXCLUDE_CHANNELS]
        print(
            f"  讀取 {os.path.basename(fpath)}：{len(channels)} 個 channels "
            f"| 分析 {len(kept_channels)} 個 channels "
            f"| 自動判斷每段時間 = {phase_duration} s"
        )

        for ch in channels:
            if int(ch) in EXCLUDE_CHANNELS:
                print(f"    跳過 CH{int(ch)}：reference / machine stable signal")
                continue

            ch_data = df[df["Channel"] == ch].copy()
            if len(ch_data) < 10:
                continue

            calib = extract_steady(ch_data, phases=phases)
            feat = extract_physics_features(ch_data, calib, phases=phases)
            label, reason = rule_based_label(calib, feat)
            wave = extract_waveform_multichannel(ch_data, phases=phases)

            if wave is None or calib is None or calib.empty:
                continue

            feat_vec = [feat.get(c, np.nan) for c in FEATURE_COLUMNS]
            feat_vec = np.nan_to_num(np.asarray(feat_vec, dtype=np.float32), nan=0.0, posinf=0.0, neginf=0.0)

            experiment_id = Path(fpath).stem
            meta = {
                "file": fpath,
                "experiment_id": experiment_id,
                "channel": int(ch) if float(ch).is_integer() else float(ch),
                "phase_duration_seconds": int(phase_duration),
                "total_assumed_seconds": float(phases[-1]["end"]),
                "teacher_label": int(label),
                "teacher_reason": reason,
            }
            meta.update(feat)

            all_waveforms.append(wave)
            all_features.append(feat_vec)
            all_labels.append(int(label))
            all_meta.append(meta)
            all_calib_dfs.append(calib)

    if len(all_waveforms) == 0:
        raise RuntimeError("沒有成功擷取任何 channel。請檢查 CSV 欄位是否包含 Channel, Interval, DeltaId。")

    X_wave = np.asarray(all_waveforms, dtype=np.float32)
    X_feat = np.asarray(all_features, dtype=np.float32)
    y = np.asarray(all_labels, dtype=np.int32)
    meta_df = pd.DataFrame(all_meta)
    groups = meta_df["experiment_id"].values

    print("\n資料集完成")
    print(f"  Channels: {len(y)}")
    print(f"  Experiments / CSV groups: {len(np.unique(groups))}")
    print(f"  Teacher valid: {int(y.sum())}")
    print(f"  Teacher invalid: {int((1 - y).sum())}")

    reason_counts = meta_df["teacher_reason"].value_counts()
    print("\n  Teacher reason 統計：")
    for reason, count in reason_counts.items():
        print(f"    - {reason}: {count}")

    if len(np.unique(y)) < 2:
        only_class = int(np.unique(y)[0])
        print("\n  [重要提醒] Teacher label 目前只有一個類別。")
        print(f"  目前全部樣本都被判成：{only_class} ({'valid' if only_class == 1 else 'invalid'})")
        print("  這代表 AI 暫時無法學習 valid vs invalid 的差異，只能輸出同一類。")
        print("  請優先檢查 channel_summary_teacher_features.csv 裡的 teacher_reason、final_drop、slope、r2。")

    safe_to_csv(meta_df, RESULT_DIR / "channel_summary_teacher_features.csv", index=False, encoding="utf-8-sig")
    return X_wave, X_feat, y, groups, meta_df, all_calib_dfs


def cross_validate(X_wave, X_feat, y, groups):
    print("\n[階段 2] 啟動交叉驗證")

    unique_groups = np.unique(groups)
    if len(unique_groups) >= 2:
        splitter = LeaveOneGroupOut()
        splits = list(splitter.split(X_wave, y, groups=groups))
        cv_name = "Leave-One-Experiment-Out"
    else:
        splitter = LeaveOneOut()
        splits = list(splitter.split(X_wave, y))
        cv_name = "Leave-One-Channel-Out fallback"
        print("  [提醒] 只有一個 CSV group，無法做 Leave-One-Experiment-Out，改用 Leave-One-Out。")

    print(f"  使用驗證方式：{cv_name}")
    print(f"  Folds: {len(splits)}")

    y_prob = np.full(len(y), np.nan, dtype=float)
    fold_id = np.full(len(y), -1, dtype=int)

    for fold, (train_idx, test_idx) in enumerate(splits, start=1):
        Xw_train, Xw_test = X_wave[train_idx], X_wave[test_idx]
        Xf_train, Xf_test = X_feat[train_idx], X_feat[test_idx]
        y_train = y[train_idx]

        if USE_KERAS:
            prob = train_predict_one_fold_keras(Xw_train, Xf_train, y_train, Xw_test, Xf_test)
        else:
            prob = train_predict_one_fold_svm(Xw_train, Xf_train, y_train, Xw_test, Xf_test)

        y_prob[test_idx] = prob
        fold_id[test_idx] = fold

        pred = (prob >= AI_THRESHOLD).astype(int)
        group_name = groups[test_idx[0]] if len(test_idx) else "NA"
        print(
            f"  Fold {fold:02d}/{len(splits)} | test group={group_name} | "
            f"n_test={len(test_idx)} | pred_valid={int(pred.sum())}/{len(pred)}"
        )

    y_pred = (y_prob >= AI_THRESHOLD).astype(int)
    return y_pred, y_prob, fold_id, cv_name


def save_reports_and_plots(X_wave, y, y_pred, y_prob, fold_id, meta_df, all_calib_dfs, cv_name):
    print("\n[階段 3] 儲存報告與圖表")

    out_df = meta_df.copy()
    out_df["fold"] = fold_id
    out_df["ai_probability"] = y_prob
    out_df["ai_prediction"] = y_pred
    out_df["match_teacher"] = (out_df["teacher_label"].values == out_df["ai_prediction"].values).astype(int)
    out_df["signal_category"] = out_df.apply(assign_signal_category, axis=1)
    safe_to_csv(out_df, RESULT_DIR / "predictions_channel_level.csv", index=False, encoding="utf-8-sig")

    category_counts = out_df["signal_category"].value_counts().reset_index()
    category_counts.columns = ["signal_category", "count"]
    safe_to_csv(category_counts, RESULT_DIR / "signal_category_counts.csv", index=False, encoding="utf-8-sig")

    # 分類報告：注意，這裡是 AI 對 teacher pseudo-label 的一致性，不是臨床診斷準確率。
    cm = confusion_matrix(y, y_pred, labels=[0, 1])
    metrics = safe_metrics(y, y_pred, y_prob)
    metrics_df = pd.DataFrame([{"cv": cv_name, **metrics}])
    safe_to_csv(metrics_df, RESULT_DIR / "metrics_classification.csv", index=False, encoding="utf-8-sig")

    with open(RESULT_DIR / "classification_report.txt", "w", encoding="utf-8") as f:
        f.write(f"CV method: {cv_name}\n")
        f.write(f"AI threshold: {AI_THRESHOLD}\n")
        f.write("Teacher labels are conservative physics-informed pseudo-labels, not absolute ground truth.\n")
        f.write("Recommended main calibration set: high_confidence_valid = Teacher valid AND AI valid.\n\n")
        f.write("Confusion matrix, labels=[0,1]:\n")
        f.write(str(cm))
        f.write("\n\n")
        f.write(classification_report(
            y,
            y_pred,
            labels=[0, 1],
            target_names=["Invalid", "Valid"],
            zero_division=0,
        ))
        f.write("\n\nMetrics:\n")
        f.write(json.dumps(metrics, indent=2, ensure_ascii=False))
        f.write("\n\nSignal category counts:\n")
        f.write(category_counts.to_string(index=False))

    plot_confusion_matrix_png(cm, RESULT_DIR / "confusion_matrix.png")

    # AI probability 統計圖與表
    prob_threshold_df = build_probability_threshold_table(y_prob, step=0.1)
    safe_to_csv(prob_threshold_df, RESULT_DIR / "ai_probability_threshold_counts.csv", index=False, encoding="utf-8-sig")
    plot_probability_threshold_bar(prob_threshold_df, RESULT_DIR / "ai_probability_threshold_counts.png")
    plot_probability_histogram(y_prob, RESULT_DIR / "ai_probability_histogram.png")

    # Calibration curve 比較
    all_calib = all_calib_dfs
    teacher_calib = [all_calib_dfs[i] for i in range(len(y)) if y[i] == 1]
    ai_calib = [all_calib_dfs[i] for i in range(len(y_pred)) if y_pred[i] == 1]
    consensus_calib = [all_calib_dfs[i] for i in range(len(y)) if y[i] == 1 and y_pred[i] == 1]
    ai_rescue_calib = [all_calib_dfs[i] for i in range(len(y)) if y[i] == 0 and y_pred[i] == 1]
    ai_reject_calib = [all_calib_dfs[i] for i in range(len(y)) if y[i] == 1 and y_pred[i] == 0]

    cal_rows = [
        analyze_calibration(all_calib, "All channels"),
        analyze_calibration(teacher_calib, "Teacher high-confidence valid"),
        analyze_calibration(ai_calib, "AI-assisted valid"),
        analyze_calibration(consensus_calib, "Consensus valid (recommended main)"),
        analyze_calibration(ai_rescue_calib, "AI rescue candidates (borderline)"),
        analyze_calibration(ai_reject_calib, "AI rejection candidates (borderline)"),
    ]
    cal_df = pd.DataFrame(cal_rows)
    safe_to_csv(cal_df, RESULT_DIR / "metrics_calibration_comparison.csv", index=False, encoding="utf-8-sig")

    # 舊版三組圖：方便跟前一版結果比較
    plot_calibration_comparison(
        all_calib,
        teacher_calib,
        ai_calib,
        RESULT_DIR / "calibration_comparison.png",
    )
    plot_log_calibration_comparison(
        all_calib,
        teacher_calib,
        ai_calib,
        RESULT_DIR / "calibration_comparison_log_scale.png",
    )

    # 建議論文使用的圖：把主結果與 borderline 分開
    recommended_sets = [
        ("All channels", all_calib),
        ("Teacher valid", teacher_calib),
        ("Consensus valid", consensus_calib),
        ("AI-assisted valid", ai_calib),
        ("AI rescue", ai_rescue_calib),
    ]
    plot_calibration_multi(
        recommended_sets,
        RESULT_DIR / "calibration_comparison_recommended.png",
        "Recommended HER2 FET-Based Biosensor Calibration Sets",
        log_x=False,
    )
    plot_calibration_multi(
        recommended_sets,
        RESULT_DIR / "calibration_comparison_recommended_log_scale.png",
        "Recommended HER2 FET-Based Biosensor Log-Scale Calibration Sets",
        log_x=True,
    )

    # 輸出每種方法各濃度平均與標準差
    for name, data_list in [
        ("all_channels", all_calib),
        ("teacher_valid", teacher_calib),
        ("ai_valid", ai_calib),
        ("consensus_valid_recommended_main", consensus_calib),
        ("ai_rescue_candidates_borderline", ai_rescue_calib),
        ("ai_rejection_candidates_borderline", ai_reject_calib),
    ]:
        stats = get_calibration_stats(data_list)
        safe_to_csv(stats, RESULT_DIR / f"calibration_stats_{name}.csv", index=False, encoding="utf-8-sig")

    # Disagreement / borderline analysis
    mismatch_idx = np.where(y != y_pred)[0]
    mismatch_df = out_df.iloc[mismatch_idx].copy()
    safe_to_csv(mismatch_df, RESULT_DIR / "mismatch_channels.csv", index=False, encoding="utf-8-sig")

    for idx in mismatch_idx:
        meta = out_df.iloc[idx].to_dict()
        if y[idx] == 0 and y_pred[idx] == 1:
            tag = "AI_rescue_rule_invalid"
        else:
            tag = "AI_reject_rule_valid"
        fname = f"{idx:03d}_{Path(meta['file']).stem}_CH{meta['channel']}_{tag}.png"
        title_extra = f"Teacher={y[idx]}, AI={y_pred[idx]}, p={y_prob[idx]:.3f}, {meta['teacher_reason']}"
        plot_one_waveform(
            X_wave[idx],
            meta,
            RESULT_DIR / "mismatch_waveforms" / fname,
            title_extra=title_extra,
            phases=build_phases(meta.get("phase_duration_seconds", DEFAULT_PHASE_DURATION_SECONDS)),
        )

    # 代表性波形：前 30 條，方便快速目視檢查
    for idx in range(min(len(y), 30)):
        meta = out_df.iloc[idx].to_dict()
        fname = f"{idx:03d}_{Path(meta['file']).stem}_CH{meta['channel']}_T{y[idx]}_AI{y_pred[idx]}.png"
        title_extra = f"Teacher={y[idx]}, AI={y_pred[idx]}, p={y_prob[idx]:.3f}, {meta['signal_category']}"
        plot_one_waveform(
            X_wave[idx],
            meta,
            RESULT_DIR / "all_waveforms" / fname,
            title_extra=title_extra,
            phases=build_phases(meta.get("phase_duration_seconds", DEFAULT_PHASE_DURATION_SECONDS)),
        )

    # 論文 / 報告用總整理圖
    save_paper_figures(X_wave, out_df, y, y_pred, y_prob, all_calib_dfs)

    consensus_count = int(np.sum((y == 1) & (y_pred == 1)))
    ai_rescue_count = int(np.sum((y == 0) & (y_pred == 1)))
    ai_reject_count = int(np.sum((y == 1) & (y_pred == 0)))

    print("\n===============================================")
    print("HER2 FET-Based Biosensor AI Validation Report")
    print("===============================================")
    print(f"CV method: {cv_name}")
    print(f"Total channels: {len(y)}")
    print(f"Teacher high-confidence valid: {int(y.sum())}")
    print(f"AI valid: {int(y_pred.sum())}")
    print(f"Consensus valid recommended main: {consensus_count}")
    print(f"AI rescue candidates borderline: {ai_rescue_count}")
    print(f"AI rejection candidates borderline: {ai_reject_count}")
    print(f"Accuracy vs teacher pseudo-label: {metrics['accuracy'] * 100:.2f}%")
    print(f"F1 vs teacher pseudo-label: {metrics['f1']:.3f}")
    print(f"MCC: {metrics['mcc']:.3f}" if np.isfinite(metrics["mcc"]) else "MCC: nan")
    print(f"ROC-AUC: {metrics['roc_auc']:.3f}" if np.isfinite(metrics["roc_auc"]) else "ROC-AUC: nan")
    print(f"PR-AUC: {metrics['pr_auc']:.3f}" if np.isfinite(metrics["pr_auc"]) else "PR-AUC: nan")

    print("\nCalibration comparison:")
    print(cal_df.to_string(index=False))

    print("\nSignal category counts:")
    print(category_counts.to_string(index=False))

    print("\nAI probability cumulative counts (>= threshold):")
    print(prob_threshold_df.to_string(index=False))

    if len(mismatch_idx) == 0:
        print("\n沒有 disagreement：AI 與 rule-based teacher 完全一致。")
    else:
        print(f"\nDisagreement / borderline channels: {len(mismatch_idx)}")
        for idx in mismatch_idx:
            row = out_df.iloc[idx]
            if y[idx] == 0 and y_pred[idx] == 1:
                state = "AI rescue candidate, teacher invalid but AI valid"
            else:
                state = "AI rejection candidate, teacher valid but AI invalid"
            print(
                f"  - {state}: {Path(row['file']).name} CH{row['channel']} | "
                f"category={row['signal_category']} | reason={row['teacher_reason']} | "
                f"prob={row['ai_probability']:.3f}"
            )

    print("\n建議主結果使用：Consensus valid (Teacher valid AND AI valid)。")
    print("AI rescue / rejection channels 建議列為 borderline supplementary analysis。")
    print(f"\n所有輸出已儲存於：{RESULT_DIR.resolve()}")
    print(f"論文 / 報告用圖位於：{(RESULT_DIR / 'paper_figures').resolve()}")

def save_config():
    config = {
        "PHASE_SEQUENCE": PHASE_SEQUENCE,
        "DEFAULT_PHASE_DURATION_SECONDS": DEFAULT_PHASE_DURATION_SECONDS,
        "AUTO_PHASE_BY_FILE": AUTO_PHASE_BY_FILE,
        "COMMON_PHASE_DURATIONS": COMMON_PHASE_DURATIONS,
        "EXCLUDE_CHANNELS": sorted(list(EXCLUDE_CHANNELS)),
        "PHASES_DEFAULT": PHASES,
        "STEADY_WINDOW_SECONDS": STEADY_WINDOW_SECONDS,
        "SKIP_SECONDS": SKIP_SECONDS,
        "TARGET_LEN": TARGET_LEN,
        "SIGNAL_THRESHOLD": SIGNAL_THRESHOLD,
        "USE_NOISE_ADAPTIVE_SIGNAL_GATE": USE_NOISE_ADAPTIVE_SIGNAL_GATE,
        "SNR_THRESHOLD_FOR_LABEL": SNR_THRESHOLD_FOR_LABEL,
        "SNR_THRESHOLD_FOR_INFO": SNR_THRESHOLD_FOR_INFO,
        "MONO_TOL": MONO_TOL,
        "MONOTONICITY_SCORE_THRESHOLD": MONOTONICITY_SCORE_THRESHOLD,
        "MAX_REVERSE_STEPS_FOR_VALID": MAX_REVERSE_STEPS_FOR_VALID,
        "R2_THRESHOLD": R2_THRESHOLD,
        "CALIBRATION_R2_MODE": CALIBRATION_R2_MODE,
        "BORDERLINE_AI_HIGH_PROB": BORDERLINE_AI_HIGH_PROB,
        "BORDERLINE_AI_LOW_PROB": BORDERLINE_AI_LOW_PROB,
        "EPOCHS": EPOCHS,
        "BATCH_SIZE": BATCH_SIZE,
        "LEARNING_RATE": LEARNING_RATE,
        "AI_THRESHOLD": AI_THRESHOLD,
        "N_AUG_POS": N_AUG_POS,
        "USE_KERAS": USE_KERAS,
        "FEATURE_COLUMNS": FEATURE_COLUMNS,
    }
    with open(RESULT_DIR / "run_config.json", "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)


def main():
    save_config()
    X_wave, X_feat, y, groups, meta_df, all_calib_dfs = collect_dataset()
    y_pred, y_prob, fold_id, cv_name = cross_validate(X_wave, X_feat, y, groups)
    save_reports_and_plots(X_wave, y, y_pred, y_prob, fold_id, meta_df, all_calib_dfs, cv_name)


if __name__ == "__main__":
    main()
